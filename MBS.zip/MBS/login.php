<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$dbhost = "localhost";
   $dbuser = "suvankar";
   $dbpass = "root";
   $dbname = "suvankar";

   $db = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysqli_real_escape_string($db,$_POST['uname']);
      $mypassword = mysqli_real_escape_string($db,$_POST['pass']); 
      
      $sql = "SELECT  *FROM login WHERE uname = '$myusername' and pass = '$mypassword'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['uname'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
         //session_register("myusername");
         $_SESSION['login_user'] = $myusername;
         header("location: welcome.php");
         
      }else {
         echo  '<font color="red" style="position: absolute; top: 30%; left: 47.8%;">*Invalid username or password</font>';
         
      }
   }

?>

<html>
    <head>
        <title>Login</title>
        
        <link rel="stylesheet" type="text/css" href="/MBS/style/style1.css" />
        
         <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
        <script>
         var app = angular.module ('myapp',[]);
            app.controller('valid', function($scope){
        
            });
        </script>
    </head>
    <body>
         <div class="container">
            
            
            <div>
                <center> <h3>SRG</h3></center><br><h4>srgPaymentBank</h4>
            </div>
            <div class="line"></div><p/><p/>
            
            <div class="login">
                <b>Existing customer:</b><p/>
                <input type="button" value="Login" onclick="window.location.href='login.php'" />
            </div>
            <div class="regis" >
                <b>New Customer:</b><p/>
                <input type="button" value="Register" onclick="window.location.href='regis.php' " />
            </div>
            
            
            <div class="foot">
                <div class="line1"></div>
                
                <div class="container2">
                    <center><b>Contact us</b><p/>
                        <b>Phone :</b> 9007414136 &nbsp;&nbsp; <b>or</b> &nbsp;&nbsp;<b> Email us:</b> srgpaymentbanks@yahoo.com<br/>
                        <b> visit our web site:</b> www.srgpaymentbank.com
                    </center>
                </div>
            </div>
            
        </div>
        <div>
            <div class="loginfrm">
                <b>Login</b><p/>
                <form method="post" action="login.php" name="form" ng-app="myapp" ng-controller="valid" novalidate >
                    <input type="text" name="uname" placeholder="Enter your CIF number" required ng-model="uname" ng-pattern="/^[0-9]{1,10}$/" >&nbsp;&nbsp;
                    <span style="color: red" ng-show="form.uname.$dirty && form.uname.$invalid" >
                        <span ng-show="form.uname.$error.required" >*CIF is required</span>
                        <span ng-show="form.uname.$error.pattern" >*enter valid CIF number </span>
                    </span><p/>
                    
                    <input type="password" name="pass" ng-model="pass" placeholder="Enter your password" required />&nbsp;&nbsp;
                    <span style="color: red" ng-show="form.pass.$dirty && form.pass.$invalid" >
                        <span ng-show="form.pass.$error.required" >*password is required</span>
                    </span><p/>
                    
                    <input type="submit" value="Login" name="login" />&nbsp;&nbsp;<a href="index.php" >Cancel</a>
                    
                </form>
            </div>
        </div>
    </body>
</html>
