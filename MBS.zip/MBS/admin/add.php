<?php
            $connect = mysqli_connect("localhost","suvankar","root","suvankar");
            if(isset($_POST['submit'])){
                $id = $_POST["id"];
                $uname = $_POST["uname"];
                $pass = $_POST["pass"];
                $kyc = $_POST["kyc"];
                
                
                $query = "insert into login(id,uname,pass,kyc) values('$id','$uname','$pass','$kyc')";
                
                if(mysqli_query($connect, $query)){
                    echo '<script>alert("Successfully updated customer database")</script>';
                    //header("Location: loginview.php");
                }else{
                    echo '<script>alert("Phone number already have an account")</script>';
                }
            }
        ?>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="/MBS/style/style1.css" />
        <style type="text/css" >
            .adminform{
                position: absolute;
                left: 45%;
                top: 30%;
            }
        </style>
        <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
        <script type="text/javascript" >
            var app = angular.module('myapp',[]);
            app.controller('valid',function($scope){
                
            });
        </script>
    </head>
    <body>
         <div class="container">
            
            
            <div>
                <center> <h3>SRG</h3></center><br/><h4>srgPaymentBank</h4>
            </div>
            <div class="line"></div><p/><p/>
        </div>
    <center><a href="logout.php" />Logout</a></center>
        <div class="adminform">
        <h2>Insert data </h2>
        <form action="add.php" method="post" name="form" ng-app="myapp" ng-controller="valid" novalidate >
            <input type="text" name="id" placeholder="Enter id of the customer" ng-model="id" required />
            <span style="color: red" ng-show="form.id.$dirty && form.id.$invalid" >
                <span ng-show="form.id.$error.required" >*ID is required</span>
            </span>
            <p></p>
            <input type="text" name="uname" placeholder="Enter customer CIF no." ng-model="uname" maxlength="10" required ng-pattern="/^\+?\d{10}$/" />
            <span style="color: red" ng-show="form.uname.$dirty && form.uname.$invalid" >
                <span ng-show="form.uname.$error.required" >*CIF NO. is required</span>
                <span ng-show="form.uname.$error.pattern">*Not valid CIF NO.</span>
            </span>
            <p></p>
            <input type="password" name="pass" placeholder="Enter customer password" ng-model="pass" maxlength="20" required />
            <span style="color: red" ng-show="form.pass.$dirty && form.pass.$invalid" >
                <span ng-show="form.pass.$error.required" >*password is required</span>
            </span>
            <p></p>
            <input type="text" name="kyc" placeholder="Enter customer Adhar card " ng-model="kyc" maxlength="16" ng-pattern="/^\+?\d{16}$/" required />
            <span style="color: red" ng-show="form.kyc.$dirty && form.kyc.$invalid" >
                <span ng-show="form.kyc.$error.required" >*ID is required</span>
                <span ng-show="form.kyc.$error.pattern" >*Not a valid Adhar No.</span> 
            </span>
            <p></p>
            <input type="submit" name="submit" value="Insert" ng-disabled="form.$invalid"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="reset" value="Reset" /><p></p>
            
        </form>
        <a href="/MBS/admin/adminwelcome.php">Cancel</a>
        </div>
    </body>
</html>
