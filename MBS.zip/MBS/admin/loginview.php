<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM login WHERE CONCAT(id,uname,pass,kyc) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM login order by id desc";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "suvankar", "root", "suvankar");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

<!DOCTYPE html>
<html>
    <head>
        <title>PHP HTML TABLE DATA SEARCH</title>
        <link rel="stylesheet" type="text/css" href="/MBS/style/style1.css" />
    </head>
    <body>
        
         <div class="container">
            
            
            <div>
                <center> <h3>SRG</h3></center><br/><h4>srgPaymentBank</h4>
            </div>
            <div class="line"></div><p/><p/>
        </div>
        <center><a href="logout.php" />Logout</a></center>
        <h1>Details of customer who can access their account</h1>
        <form action="loginview.php" method="post">
            <input type="text" name="valueToSearch" placeholder="Value To Search">
            <input type="submit" name="search" value="Filter"><br><br>
            
            <table border="1">
                <tr>
                    <th>Id</th>
                    <th>USER NAME</th>
                    <th>PASSWORD</th>
                    <th>KYC</th>
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    <td><?php echo $row['id'];?></td>
                    <td><?php echo $row['uname'];?></td>
                    <td><?php echo $row['pass'];?></td>
                    <td><?php echo $row['kyc'];?></td>
                    <td><?php echo "<input type='button' value='Edit' onclick='window.location.href=\"edit2.php?id=$row[id]\"'>"; ?></td>
                    <td><?php echo "<input type='button' value='Delete' onclick='window.location.href=\"delete2.php?id=$row[id]\"'>"; ?></td>
                </tr>
                <?php endwhile;?>
            </table>
        </form>
        <a href="/MBS/admin/adminwelcome.php">Back</a>
    </body>
</html>
