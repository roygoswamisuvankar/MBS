<?php

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM bank WHERE CONCAT(phone,bank,acno,type,bal) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM bank order by acno desc";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "suvankar", "root", "suvankar");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

<!DOCTYPE html>
<html>
    <head>
        <title>PHP HTML TABLE DATA SEARCH</title>
        <link rel="stylesheet" type="text/css" href="/MBS/style/style1.css" />
    </head>
    <body>
        
         <div class="container">
            
            
            <div>
                <center> <h3>SRG</h3></center><br/><h4>srgPaymentBank</h4>
            </div>
            <div class="line"></div><p/><p/>
        </div>
        <center><a href="logout.php" />Logout</a></center>
        <h1>Details of customer's Bank Account</h1>
        <form action="loginview.php" method="post">
            <input type="text" name="valueToSearch" placeholder="Value To Search">
            <input type="submit" name="search" value="Filter"><br><br>
            
            <table border="1">
                <tr>
                    <th>USER ACCOUNT ID</th>
                    <th>BANK</th>
                    <th>ACCOUNT NO.</th>
                    <th>ACCOUNT TYPE</th>
                    <th>BALANCE</th>
                </tr>

      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    <td><?php echo $row['phone'];?></td>
                    <td><?php echo $row['bank'];?></td>
                    <td><?php echo $row['acno'];?></td>
                    <td><?php echo $row['type'];?></td>
                    <td><?php echo $row['bal'];?></td>
                    
                </tr>
                <?php endwhile;?>
            </table>
        </form>
        <a href="/MBS/admin/adminwelcome.php">Back</a>
    </body>
</html>
