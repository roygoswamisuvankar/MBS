<?php
	session_start();
	unset($_SESSION['uname']);
	unset($_SESSION['pass']);
	echo "<script type='text/javascript'>alert('You have successfully logout');
window.location='adminhome.php';
</script>";
	header('Refresh:1;URL=adminhome.php');
?>