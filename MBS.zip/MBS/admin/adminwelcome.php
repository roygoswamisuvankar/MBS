

<html>
    <head>
        <title>Srg Admin</title>
        <link rel="stylesheet" type="text/css" href="/MBS/style/style1.css" />
    </head>
    
    <body>
        <div class="container">
            
            
            <div>
                <center> <h3>SRG</h3></center><br/><h4>srgPaymentBank</h4>
            </div>
            <div class="line"></div><p/><p/>
        </div>
        
            <center><b>Welcome Admin</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="logout.php" />Logout</a></center>
    
    <table border="1">
        <thead>
        <th>Admin Control Pannel</th>
        </thead>
        <tbody>
        <td><input type="button" onclick="window.location.href='viewcust.php'" value="View Customer Details"/></td>
        <td><input type="button" onclick="window.location.href='loginview.php'" value="View Login Customer Details"/></td>
        <td><input type="button" onclick="window.location.href='add.php'" value="Insert CIF NO."/></td>
        <td><input type="button" onclick="window.location.href='adbank.php'" value="View Bank"/></td>
        </tbody>
    </table>
    </body>
</html>