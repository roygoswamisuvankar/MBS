<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if(isset($_POST['search']))
{
    $valueToSearch = $_POST['value'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM regis_cust WHERE CONCAT(id,name,gen,dob,email,phone,pass,pcn) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM regis_cust order by id desc";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "suvankar", "root", "suvankar");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}


?>

<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="/MBS/style/style1.css" />
    </head>
    <body>
        <div class="container">
            
            
            <div>
                <center> <h3>SRG</h3></center><br/><h4>srgPaymentBank</h4>
            </div>
            <div class="line"></div><p/><p/>
        </div>
        <center><a href="logout.php" />Logout</a></center>
        <h1>Details of customer who are currently registered</h1>
        <form action="viewcust.php" method="post" name="myform" >
            <input type="text" placeholder="Search data" name="value" />
            <input type="submit" value="search" name="search" />
        <table border="1">
            <thead>
            <th>ID</th>
            <th>NAME</th>
            <th>GENDER</th>
            <th>DATE OF BIRTH</th>
            <th>EMAIL ADDRESS</th>
            <th>PHONE NO.</th>
            <th>PASSWORD</th>
            <th>PROVIDED CIF NO.</th>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    <td><?php echo $row['id'];?></td>
                    <td><?php echo $row['name'];?></td>
                    <td><?php echo $row['gen'];?></td>
                    <td><?php echo $row['dob'];?></td>
                    <td><?php echo $row['email'];?></td>
                    <td><?php echo $row['phone'];?></td>
                    <td><?php echo $row['pass'];?></td>
                    <td><?php echo $row['pcn'];?></td>
                    <td><?php echo "<input type='button' value='Edit' onclick='window.location.href=\"edit.php?id=$row[id]\"'"; ?></td>
                    <td><?php echo "<input type='button' value='Delete' onclick='window.location.href=\"delete.php?id=$row[id]\"'"; ?></td>
                </tr>
                <?php endwhile;?>

            </tbody>
        </table>
        </form>
        <a href="/MBS/admin/adminwelcome.php">Back</a>
    </body>
</html>
