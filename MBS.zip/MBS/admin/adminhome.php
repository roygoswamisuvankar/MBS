

<?php
    session_start();
    if (isset($_POST['login']) && !empty($_POST['uname']) 
               && !empty($_POST['pass'])) {
				
               if ($_POST['uname'] == 'suvankar' && 
                  $_POST['pass'] == 'root') {
                  $_SESSION['valid'] = true;
                  $_SESSION['timeout'] = time();
                  $_SESSION['uname'] = 'avirup';
                  
                  header("Location: adminwelcome.php");
               }else {
            		echo "<font color='red' style='position: absolute; top: 29%; left: 45%;'>Wrong Username or Password</font>";

                }
            }
         
?>

<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="/MBS/style/style1.css" />
        <style type="text/css">
            .adminform{
                position: absolute;
                left: 45%;
                top: 30%;
            }
        </style>
    </head>
    <body>
        <div class="container">
            
            
            <div>
                <center> <h3>SRG</h3></center><br><h4>srgPaymentBank</h4>
            </div>
            <div class="line"></div><p/><p/>
        
        <div>
            <div class="adminform">
                <form action="adminhome.php" method="post" name="form">
                    <h3>Login Admin</h3>
                    <input type="text" name="uname" placeholder="Enter admin user name" required /><p></p>
                    <input type="password" name="pass" placeholder="Enter admin password" required /><p></p>
                    <input type="submit" value="Login" name="login"/>
                </form>
            </div>
        </div>
    </body>
</html>