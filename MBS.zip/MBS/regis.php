<!DOCTYPE html>
<!--
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
-->
<html>
    <head>
        <meta charset="windows-1252">
        <title></title>
        <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
        <link rel="stylesheet" type="text/css" href="/MBS/style/style1.css" />
        <script type="text/javascript" >
            var app = angular.module('myapp',[]);
            app.controller('valid',function($scope){
                
            });
        </script>
    </head>
    <style type="text/css">
        input[type=email], input[type=date]{
             border: 2px solid black;
    padding: 4px 8px;
    border-radius: 2px;
        }
        .loginfrm2{
    position: absolute;
    top: 30%;
    left: 46%;
}
    </style>
    <body>
        <?php
            $connect = mysqli_connect("localhost","suvankar","root","suvankar");
            if(isset($_POST['submit'])){
                $name = $_POST["name"];
                $gen = $_POST["gen"];
                $dob = $_POST["dob"];
                $email = $_POST["email"];
                $phone = $_POST["phone"];
                $pass = $_POST["pass"];
                $pcn = $_POST["pcn"];
                
                $query = "insert into regis_cust(name,gen,dob,email,phone,pass,pcn) values('$name','$gen','$dob','$email','$phone','$pass','$pcn')";
                
                if(mysqli_query($connect, $query)){
                    echo '<script>alert("You have successfully create your account,CIF number and password is send to you by sms")</script>';
                }else{
                    echo '<script>alert("Phone number already have an account")</script>';
                }
            }
        ?>
        <div class="container">
            
            
            <div>
                <center> <h3>SRG</h3></center><br><h4>srgPaymentBank</h4>
            </div>
            <div class="line"></div><p/><p/>
            
            <div class="login">
                <b>Existing customer:</b><p/>
                <input type="button" value="Login" onclick="window.location.href='login.php'" />
            </div>
            <div class="regis" >
                <b>New Customer:</b><p/>
                <input type="button" value="Register" onclick="window.location.href='regis.php' " />
            </div>
            
            
            <div class="foot">
                <div class="line1"></div>
                
                <div class="container2">
                    <center><b>Contact us</b><p/>
                        <b> Phone :</b> 9007414136 &nbsp;&nbsp; <b>or</b> &nbsp;&nbsp;<b> Email us:</b> srgpaymentbanks@yahoo.com<br/>
                        <b>visit our web site:</b> www.srgpaymentbank.com
                    </center>
                </div>
            </div>
            
        </div>
        <div>
            <div class="loginfrm2">
                <form action="regis.php" method="post" name="form" ng-app="myapp" ng-controller="valid" novalidate >
                    <input type="text" name="name" placeholder="Enter your full name" required ng-model="name" ng-pattern="/^[a-zA-Z ]*$/"/>&nbsp;&nbsp;
                    <span style="color: red" ng-show="form.name.$dirty && form.name.$invalid" >
                        <span ng-show="form.name.$error.required" >*Name is required</span>
                        <span ng-show="form.name.$error.pattern" >*Enter valid Name</span>
                    </span><p><p/>
                    <input type="radio" value="M" name="gen" required ng-model="gen"/>Male &nbsp;&nbsp; <input type="radio" value="F" name="gen" required ng-model="gen"/>Female&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span style="color: red" ng-show="form.gen.$dirty && form.gen.$invalid" >
                        <span ng-show="form.gen.$error.required" >*gender is required</span>
                    </span>
                    <p></p>
                    <input type="date" required ng-model="dob" name="dob"/>&nbsp;&nbsp;
                    <span style="color: red" ng-show="form.dob.$dirty && form.dob.$invalid" >
                        <span ng-show="form.dob.$error.required" >*date of birth is required</span>
                    </span>
                    <p></p>
                    <input type="email" name="email" placeholder="Enter your email address" required ng-model="email"/>&nbsp;&nbsp;
                    <span style="color: red" ng-show="form.email.$dirty && form.email.$invalid" >
                        <span ng-show="form.email.$error.required" >*email address is required</span>
                        <span ng-show="form.email.$error.email" >*Enter valid email address</span>
                    </span>
                    <p></p>
                    <input type="text" name="phone" placeholder="Enter your phone number" maxlength="10" required ng-model="phone"ng-pattern="/^\+?\d{10}$/"/>&nbsp;&nbsp;
                    <span style="color: red" ng-show="form.phone.$dirty && form.phone.$invalid" >
                        <span ng-show="form.phone.$error.required" >*phone number is required</span>
                        <span ng-show="form.phone.$error.pattern" >*Enter valid phone number</span>
                    </span>
                    <p></p>
                    <input type="password" name="pass" placeholder="Enter password" required ng-model="pass"/>&nbsp;&nbsp;
                    <span style="color: red" ng-show="form.pass.$dirty && form.pass.$invalid" >
                        <span ng-show="form.pass.$error.required" >*password is required</span>
                    </span>
                    <br/>
                    <input type="checkbox" required ng-model="check" name="check"/>Accept Terms and Condition
                    <span style="color: red" ng-show="form.check.$dirty && form.check.$invalid" >
                        <span ng-show="form.check.$error.required" ></span>
                    </span>
                    <br/>
                    <input type="hidden" value="NO" name="pcn" />
                    <input type="submit" value="Submit" name="submit" ng-disabled="form.$invalid" />&nbsp;&nbsp;&nbsp;
                    <input type="reset" value="Reset" />&nbsp;&nbsp;&nbsp;
                    <a href="index.php" >Cancel</a>
                    
                </form>
            </div>
        </div>
    </body>
</html>


