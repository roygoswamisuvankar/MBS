<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="windows-1252">
        <title></title>
        <link rel="stylesheet" type="text/css" href="/MBS/style/style1.css" />
        <style type="text/css">
            .terms{
                position: absolute;
                top: 25%;
                left: 40%;
            }
        </style>
    </head>
    <body>
        
        <div class="container">
            
            
            <div>
                <center> <h3>SRG</h3></center><br/><h4>srgPaymentBank</h4>
            </div>
            <div class="line"></div><p/><p/>
            
            <div class="login">
                <b>Existing customer:</b><p/>
                <input type="button" value="Login" onclick="window.location.href='login.php'" />
            </div>
            <div class="regis" >
                <b>New Customer:</b><p/>
                <input type="button" value="Register" onclick="window.location.href='regis.php' " />
            </div>
            
            
            <div class="foot">
                <div class="line1"></div>
                <div class="terms" >
                    <h3 style="color: #33bbff">Terms & Conditions</h3>
                    <ul>
                        <li>Welcome to SRG Payment Bank Account.</li>
                        <li>It's a third party app to make your Payment<br/>easy.</li>
                        <li>Only a unique phone number is used to open<br/>an account.</li>
                        <li>You can payment bills, reacharge easily with wallet or net bankaing<br>
                        or debit card or visa and rupe card.
                        </li>
                        <li>You can payment cedit card loans.</li>
                        <li>You can add your bank account or debit card or credit card</li>
                        <li>You can took instant loan in very small interest in any bank <br/>or you can pay it's EMI easily.</li>
                        <li>It's a smart and secure payment third party app</li>
                    </ul>
                </div>
                
                <div class="container2">
                    <center><b>Contact us</b><p/>
                        <b> Phone :</b> 9007414136 &nbsp;&nbsp; <b>or</b> &nbsp;&nbsp;<b> Email us:</b> srgpaymentbanks@yahoo.com<br/>
                        <b>visit our web site:</b> www.srgpaymentbank.com
                    </center>
                </div>
            </div>
            
        </div>
    </body>
</html>
