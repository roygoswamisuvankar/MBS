<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include 'session.php';
?>
<html>
    <head>
        <title>Add Debit Card</title>
        <link rel="stylesheet" type="text/css" href="/MBS/style/style1.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
        <style type="text/css">
            .debit{
                position: absolute;
                left: 45%;
                top: 20%;
            }
            .box{
        
        display: none;
       
    }
    .show{
        position: absolute;
        left: 45%;
        top: 20%;
    }
        </style>
        <script type="text/javascript" >
            var app = angular.module('myapp',[]);
            app.controller('valid',function($scope){
                
            });
        </script>
        <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
            <script type="text/javascript">
            $(document).ready(function(){
                $('input[type="radio"]').click(function(){
                    var inputValue = $(this).attr("value");
                    var targetBox = $("." + inputValue);
                    $(".box").not(targetBox).hide();
                    $(targetBox).show();
                });
            });
            </script>
    </head>
    <body>
        <div class="container">
            
            
            <div>
                <center> <h3>SRG</h3></center><br><h4>srgPaymentBank</h4>
            </div>
            <div class="line"></div><p/><p/>
            
            
            
            
            <div class="foot">
                <div class="line1"></div>
                
                <div class="container2">
                    <center><b>Contact us</b><p/>
                        <b> Phone :</b> 9007414136 &nbsp;&nbsp; <b>or</b> &nbsp;&nbsp;<b> Email us:</b> srgpaymentbanks@yahoo.com<br/>
                        <b>visit our web site:</b> www.srgpaymentbank.com
                    </center>
                </div>
            </div>
        </div>
        <center>Account :<?php echo $login_session; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="logout.php">logout</a></center>
    <?php
    $connect = mysqli_connect("localhost","suvankar","root","suvankar");
           
                    if(isset($_POST['submit'])){
                        $phone = $_POST["phone"];
                        $crdno = $_POST["crdno"];
                $name = $_POST["name"];
                $cvv = $_POST["cvv"];
                $mm = $_POST["mm"];
                $yy = $_POST["yy"];
                
                
                $query = "insert into debit_card(phone,crdno,name,cvv,mm,yy) values('$phone','$crdno','$name','$cvv','$mm','$yy')";
                
                if(mysqli_query($connect, $query)){
                    echo '<script>alert("Your Debit Card added successfully")</script>';
                }else{
                    echo '<script>alert("Card number already exits")</script>';
                }
              }
    ?>
    <div class="">
        <label><input type="radio" name="radio" value="debit" />Add Debit Card</label>
        <label><input type="radio" name="radio" value="show" />Show Debit Card</label>
    </div>
        <div class="debit box" >
            
            <h3>Enter Your Card Details</h3>
            <form action="add_debit.php" method="post" name="form" ng-app="myapp" ng-controller="valid" novalidate >
                <input type="hidden" value="<?php echo $login_session ?>" name="phone" />
                
                <input type="text" name="crdno" maxlength="16" placeholder="1111-2222-3333-4444" ng-model="crdno" ng-pattern="/^\+?\d{16}$/" required />
                <span style="color: red" ng-show="form.crdno.$dirty && form.crdno.$invalid" >
                 <span ng-show="form.crdno.$error.required" >*Card number is required</span>
                 <span ng-show="form.crdno.$error.pattern" >*Enter valid Card number</span>
                </span>
                <p></p>
                <input type="text" name="name" ng-model="name" placeholder="Enter Card Holder Name" ng-pattern="/^[a-zA-Z ]*$/" required />
                <span style="color: red" ng-show="form.name.$dirty && form.name.$invalid" >
                        <span ng-show="form.name.$error.required" >*Name is required</span>
                        <span ng-show="form.name.$error.pattern" >*Enter valid Name</span>
                </span>
                <p></p>
                <input type="password" name="cvv" ng-model="cvv" placeholder="CVV" maxlength="3" ng-pattern="/^\+?\d{3}$/" required />
                <span style="color: red" ng-show="form.cvv.$dirty && form.cvv.$invalid" >
                 <span ng-show="form.cvv.$error.required" >*Card number is required</span>
                 <span ng-show="form.cvv.$error.pattern" >*Enter valid Card number</span>
                </span>
                <p></p>
                <select name="mm" >
                    <option value="JAN" >JAN</option>
                    <option value="FEB" >FEB</option>
                    <option value="MAR" >MAR</option>
                    <option value="APRL" >APRL</option>
                    <option value="MAY" >MAY</option>
                    <option value="JUN" >JUN</option>
                    <option value="JUL" >JUL</option>
                    <option value="AUG" >AUG</option>
                    <option value="SEPT" >SEPT</option>
                    <option value="OCT" >OCT</option>
                    <option value="NOV" >NOV</option>
                    <option value="DEC" >DEC</option>
                </select> / 
                <select name="yy" >
                    <option value="2019" >2019</option>
                    <option value="2020" >2020</option>
                    <option value="2021" >2021</option>
                    <option value="2022" >2022</option>
                    <option value="2023" >2023</option>
                    <option VALUE="2024" >2024</option>
                    <option value="2025" >2025</option>
                </select><p></p>
                <input type="submit" value="submit" name="submit" />
            </form>
        </div>
    <div class="show box">
        <?php
            $dbhost = "localhost";
	$dbname = "suvankar";
	$dbuser = "suvankar";
	$dbpass = "root";

	$mysqli = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
        
        $result = mysqli_query($mysqli,"select *from debit_card where phone = $login_session ");
				while($row=mysqli_fetch_array($result))
				{
                                    echo 'SL. NO.: '.$row['id'].'</br>';
                                    echo 'Card Number: '.$row['crdno'].'</br>';
                                    echo 'Card Holder Name. : '.$row['name'].'</br>';
                                    echo 'CVV: '.$row['cvv'].'</br>';
                                    echo 'Expirity Date: '.$row['mm'].' / ';
                                    echo $row['yy'];
                                    echo '<br/>';
                                    echo "<input type='button' value='Remove Card' onclick='window.location.href=\"delete_card.php?id=$row[id]\"'><br/><br/>";
                                }
        ?>
    </div>
    <div>
        <h3>Our Services :</h3>
        <ul>
            <li><a href="show_wallet.php">Wallet</a></li>
            <li><a href="addbank.php">Add bank account</a></li>
            <li><a href="show_bank.php">Check Bank </a></li>
            <li><a href="add_debit.php">Add Debit Card</a></li>
            <li><a href="">Money Transfer</a></li>
            <li><a href="">Money Withdraw</a></li>
            <li><a href="">Bill Payment</a></li>
            <li><a href="">Recharge</a></li>
        </ul>
        
    </div>
    </body>
</html>

