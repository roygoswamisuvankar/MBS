<?php

include 'session.php';
?>
<html>
    <head>
        <title>
            Bank
        </title>
        <link rel="stylesheet" type="text/css" href="/MBS/style/style1.css" />
        <style>
            .bank{
                position: absolute;
                left: 45%;
                top: 20%;
            }
        </style>
    </head>
    <body>
        <?php
	$dbhost = "localhost";
	$dbname = "suvankar";
	$dbuser = "suvankar";
	$dbpass = "root";

	$mysqli = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);


        ?>
        
        <div class="container">
            
            
            <div>
                <center> <h3>SRG</h3></center><br><h4>srgPaymentBank</h4>
            </div>
            <div class="line"></div><p/><p/>
            
            
            
            
            <div class="foot">
                <div class="line1"></div>
                
                <div class="container2">
                    <center><b>Contact us</b><p/>
                        <b> Phone :</b> 9007414136 &nbsp;&nbsp; <b>or</b> &nbsp;&nbsp;<b> Email us:</b> srgpaymentbanks@yahoo.com<br/>
                        <b>visit our web site:</b> www.srgpaymentbank.com
                    </center>
                </div>
            </div>
        </div>
        <center>Account :<?php echo $login_session; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="logout.php">logout</a></center>
        <div class="bank">
            <h3>Your Bank Details</h3>
        <?php 
				$result = mysqli_query($mysqli,"select *from bank where phone = $login_session ");
				while($row=mysqli_fetch_array($result))
				{
                                    echo 'SL. NO.:'.$row['id'].'</br>';
                                    echo 'Bank Name: '.$row['bank'].'</br>';
                                    echo 'Account No. : '.$row['acno'].'</br>';
                                    echo 'Account Type: '.$row['type'].'</br>';
                                    echo 'Account Balance: Rs. '.$row['bal'].'/-</br>';
                                    echo "<input type='button' value='Remove Bank' onclick='window.location.href=\"delete_bank.php?id=$row[id]\"'><br/><br/>";
                                }
	?>
            <input type="button" value="Add Another Bank" onclick="window.location.href='addbank.php'"/> 
        </div>
   
    <div>
        <h3>Our Services :</h3>
        <ul>
            <li><a href="show_wallet.php">Wallet</a></li>
            <li><a href="addbank.php">Add bank account</a></li>
            <li><a href="show_bank.php">Check Bank </a></li>
            <li><a href="add_debit.php">Add Debit Card</a></li>
            <li><a href="">Money Transfer</a></li>
            <li><a href="">Money Withdraw</a></li>
            <li><a href="">Bill Payment</a></li>
            <li><a href="">Recharge</a></li>
        </ul>
        
    </div>
    </body>
</html>