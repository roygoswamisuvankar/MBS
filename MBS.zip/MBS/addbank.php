<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include 'session.php';
?>

<html>
    <head>
        <title>Add Bank Account</title>
        <link rel="stylesheet" type="text/css" href="/MBS/style/style1.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>
        <script type="text/javascript" >
            var app = angular.module('myapp',[]);
            app.controller('valid',function($scope){
                
            });
        </script>
        <style>
            .bankfrm{
                position: absolute;
                left: 45%;
                top: 30%;
            }
            
        </style>
    </head>
    <body>
        
        <div class="container">
            
            
            <div>
                <center> <h3>SRG</h3></center><br><h4>srgPaymentBank</h4>
            </div>
            <div class="line"></div><p/><p/>
            
            
            
            
            <div class="foot">
                <div class="line1"></div>
                
                <div class="container2">
                    <center><b>Contact us</b><p/>
                        <b> Phone :</b> 9007414136 &nbsp;&nbsp; <b>or</b> &nbsp;&nbsp;<b> Email us:</b> srgpaymentbanks@yahoo.com<br/>
                        <b>visit our web site:</b> www.srgpaymentbank.com
                    </center>
                </div>
            </div>
        </div>
        <center>Account :<?php echo $login_session; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="logout.php">logout</a></center>
           <?php
           
           $connect = mysqli_connect("localhost","suvankar","root","suvankar");
           
                    if(isset($_POST['submit'])){
                        $name = $_POST["phone"];
                $bank = $_POST["bank"];
                $acno = $_POST["acno"];
                $type = $_POST["type"];
                
                
                $query = "insert into bank(phone,bank,acno,type) values('$name','$bank','$acno','$type')";
                
                if(mysqli_query($connect, $query)){
                    echo '<script>alert("your Account will verify soon")</script>';
                }else{
                    echo '<script>alert("Account number already exits")</script>';
                }
              }
            
           ?>
    
            <div class="bankfrm" >
                <form action="addbank.php" method="post" name="form" ng-app="myapp" ng-controller="valid" novalidate>
                    User ID:<br/>
                    <input type="text" value="<?php echo $login_session ?>" name="phone" readonly /><p></p>
                    Select your bank :<br/>
                    <select name="bank" required >
                        <option value="">Select</option>
                        <option value="HDFC BANK">HDFC BANK</option>
                        <option value="ALLABAHAD BANK">ALLABAHAD BANK</option>
                        <OPTION value="YES BANK">YES BANK</OPTION>
                        <OPTION value="STATE BANK OF INDIA">STATE BANK OF INDIA</OPTION>
                        <OPTION value="CENTRAL BANK OF INDIA">CENTRAL BANK OF INDIA</OPTION>
                    </select><p></p>
                    Enter your Bank Account NO. :<br/>
                    <input type="text" name="acno" placeholder="12345678910" required ng-model="acno" ng-pattern="/^\+?\d{10}$/" maxlength="10"/>
                    <span style="color: red" ng-show="form.acno.$dirty && form.acno.$invalid" >
                        <span ng-show="form.acno.$error.required" >*phone number is required</span>
                        <span ng-show="form.acno.$error.pattern" >*Enter valid phone number</span>
                    </span>
                    <p></p>
                    Select Account Type:<br/>
                    <select name="type" required >
                        <option value="">Select</option>
                        <option value="Current Account">Current Account</option>
                        <option value="Savings Account">Savings Account</option>
                        <option value="Salary Account">Salary Account</option>
                    </select><p></p>
                    <input type="submit" value="Verify" name="submit" ng-disabled="form.$invalid" />
                </form>
            </div>
    
    <div>
        <h3>Our Services :</h3>
        <ul>
            <li><a href="show_wallet.php">Wallet</a></li>
            <li><a href="addbank.php">Add bank account</a></li>
            <li><a href="show_bank.php">Check Bank </a></li>
            <li><a href="add_debit.php">Add Debit Card</a></li>
            <li><a href="">Money Transfer</a></li>
            <li><a href="">Money Withdraw</a></li>
            <li><a href="">Bill Payment</a></li>
            <li><a href="">Recharge</a></li>
        </ul>
        
    </div>
    </body>
</html>