<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

include 'session.php';

?>
<?php
	$dbhost="localhost";
	$dbname="suvankar";
	$dbuser="suvankar";
	$dbpass="root";

	$mysqli=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);

	$id=$_GET['id'];

	$result=mysqli_query($mysqli,"delete from bank where id=$id");
	header("Location: show_bank.php");
?>


