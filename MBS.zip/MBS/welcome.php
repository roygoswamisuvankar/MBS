


<?php
   include('session.php');
   
?>

<html>
    <head>
        <title>welcome</title>
        <link rel="stylesheet" type="text/css" href="/MBS/style/style1.css" />
    </head>
    <body>
        <div class="container">
            
            
            <div>
                <center> <h3>SRG</h3></center><br><h4>srgPaymentBank</h4>
            </div>
            <div class="line"></div><p/><p/>
            
            
            
            
            <div class="foot">
                <div class="line1"></div>
                
                <div class="container2">
                    <center><b>Contact us</b><p/>
                        <b> Phone :</b> 9007414136 &nbsp;&nbsp; <b>or</b> &nbsp;&nbsp;<b> Email us:</b> srgpaymentbanks@yahoo.com<br/>
                        <b>visit our web site:</b> www.srgpaymentbank.com
                    </center>
                </div>
            </div>
            
        </div>
        <center>Welcome &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $login_session; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="logout.php">logout</a></center>

    
    
    <div>
        <h3>Our Services :</h3>
        <ul>
            <li><a href="show_wallet.php">Wallet</a></li>
            <li><a href="addbank.php">Add bank account</a></li>
            <li><a href="show_bank.php">Check Bank </a></li>
            <li><a href="add_debit.php">Add Debit Card</a></li>
            <li><a href="">Money Transfer</a></li>
            <li><a href="">Money Withdraw</a></li>
            <li><a href="">Bill Payment</a></li>
            <li><a href="">Recharge</a></li>
        </ul>
        
    </div>
    </body>
</html>