<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include 'session.php';
?>

<html>
    <head>
        <title>Pyment</title>
        <link rel="stylesheet" type="text/css" href="/MBS/style/style1.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
        
        <script type="text/javascript" >
            var app = angular.module('myapp',[]);
            app.controller('valid',function($scope){
                
            });
        </script>
          <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
            <script type="text/javascript">
            $(document).ready(function(){
                $('input[type="radio"]').click(function(){
                    var inputValue = $(this).attr("value");
                    var targetBox = $("." + inputValue);
                    $(".box").not(targetBox).hide();
                    $(targetBox).show();
                });
            });
            </script>

        <style type="text/css" >
            .pay{
                position: absolute;
                left: 45%;
                top: 20%;
            }
            .box{
        
        
        display: none;
       
    }
        </style>
    </head>
    <body>
         <div class="container">
            
            
            <div>
                <center> <h3>SRG</h3></center><br><h4>srgPaymentBank</h4>
            </div>
            <div class="line"></div><p/><p/>
            
            
            
            
            <div class="foot">
                <div class="line1"></div>
                
                <div class="container2">
                    <center><b>Contact us</b><p/>
                        <b> Phone :</b> 9007414136 &nbsp;&nbsp; <b>or</b> &nbsp;&nbsp;<b> Email us:</b> srgpaymentbanks@yahoo.com<br/>
                        <b>visit our web site:</b> www.srgpaymentbank.com
                    </center>
                </div>
            </div>
        </div>
        <center>Account :<?php echo $login_session; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="logout.php">logout</a></center>
        <?php
                if(isset($_POST['add'])){
                    $bal = $_POST['bal'];
                    
                }
            ?>
        <div class="pay">
        <form action="" method="post" name="form" >
            
            Amount:<br/>
            <input type="text" value="<?php echo $bal; ?>" name="bal"  readonly />
            
        </form>   
            <p></p>
            
            <div class="payment">
                <h3>Enter your Payment Method</h3>
                <div>
        <label><input type="radio" name="pay" value="debit"> Debit Card</label>
        <label><input type="radio" name="pay" value="credit"> Net Banking</label>
        
    </div>
    <div class="debit box">
        <form action="#" method="post" name="form" ng-app="myapp" ng-controller="valid" novalidate >
            <input type="hidden" value="<?php echo $bal; ?>" name="bal"  readonly />
            
            <input type="text" placeholder="1111-2222-3333-4444" maxlength="16" required ng-model="crdno" name="crdno" ng-pattern="/^\+?\d{16}$/" />
            <span style="color: red" ng-show="form.crdno.$dirty && form.crdno.$invalid" >
                 <span ng-show="form.crdno.$error.required" >*Card number is required</span>
                 <span ng-show="form.crdno.$error.pattern" >*Enter valid Card number</span>
            </span>
            <p/>
            <input type="text" placeholder="Enter card holder name" name="name" ng-model="name" required ng-pattern="/^[a-zA-Z ]*$/"/>&nbsp;
            <span style="color: red" ng-show="form.name.$dirty && form.name.$invalid" >
                        <span ng-show="form.name.$error.required" >*Name is required</span>
                        <span ng-show="form.name.$error.pattern" >*Enter valid Name</span>
                    </span>
            <p></p>
            <input type="password" placeholder="cvv" name="cvv" maxlength="3" ng-model="cvv" required ng-pattern="/^\+?\d{3}$/" />
            <span style="color: red" ng-show="form.cvv.$dirty && form.cvv.$invalid" >
                 <span ng-show="form.cvv.$error.required" >*CVV number is required</span>
                 <span ng-show="form.cvv.$error.pattern" >*Enter valid CVV number</span>
            </span>
            <p><p/>
            
            Month: &nbsp;&nbsp;&nbsp;&nbsp;/ Year:<br/>
            <select>
                <option>JAN</option>
                <option>FEB</option>
                <option>MAR</option>
                <option>APRL</option>
                <option>MAY</option>
                <option>JUN</option>
                <option>JUL</option>
                <option>AUG</option>
                <option>SEPT</option>
                <option>OCT</option>
                <option>NOV</option>
                <option>DEC</option>
            </select> &nbsp; / 
            <select>
                <option>2019</option>
                <option>2020</option>
                <option>2021</option>
                <option>2022</option>
                <option>2023</option>
                <option>2024</option>
                <option>2025</option>
                <option>2026</option>
                <option>2027</option>
                <option>2028</option>
                <option>2029</option>
                <option>2030</option>
            </select>
            <p/>
                
                <input type="submit" value="submit" />
        </form>
    </div>
                   
    <div class="credit box">
    <form action="#" >
        <h3>Select Your Bank Name</h3>
        <select name="bank">
            <option value="1">ALLABAHAD BANK</option>
            <option>STATE BANK OF INDIA</option>
            <OPTION>CENTRAL BANK OF INDIA</option>
            <OPTION>AXIS BANK</option>
        </select>
        <input type="submit" value="GO" />
        </form>
    </div>
                
            </div>
        
        </div>
         <div>
        <h3>Our Services :</h3>
        <ul>
            <li><a href="show_wallet.php">Wallet</a></li>
            <li><a href="addbank.php">Add bank account</a></li>
            <li><a href="show_bank.php">Check Bank </a></li>
            <li><a href="add_debit.php">Add Debit Card</a></li>
            <li><a href="">Money Transfer</a></li>
            <li><a href="">Money Withdraw</a></li>
            <li><a href="">Bill Payment</a></li>
            <li><a href="">Recharge</a></li>
        </ul>
        
    </div>   
    </body>
</html>

