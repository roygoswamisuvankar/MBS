<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

include 'session.php';
?>
<html>
    <head>
        <title>
            wallet
        </title>
        <link rel="stylesheet" type="text/css" href="/MBS/style/style1.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
        <script type="text/javascript" >
            var app = angular.module('myapp',[]);
            app.controller('valid',function($scope){
                
            });
        </script>
        <style type="text/css" >
            .h{
                position: absolute;
                top: 10%;
            }
            .frm{
                position: absolute;
                top: 30%;
                left: 45%;
            }
        </style>
        
    </head>
    <body>
        <?php
	$dbhost = "localhost";
	$dbname = "suvankar";
	$dbuser = "suvankar";
	$dbpass = "root";

	$mysqli = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);


        ?>
        <div class="container">
            
            
            <div>
                <center> <h3>SRG</h3></center><br><h4>srgPaymentBank</h4>
            </div>
            <div class="line"></div><p/><p/>
            
            
            
            
            <div class="foot">
                <div class="line1"></div>
                
                <div class="container2">
                    <center><b>Contact us</b><p/>
                        <b> Phone :</b> 9007414136 &nbsp;&nbsp; <b>or</b> &nbsp;&nbsp;<b> Email us:</b> srgpaymentbanks@yahoo.com<br/>
                        <b>visit our web site:</b> www.srgpaymentbank.com
                    </center>
                </div>
            </div>
        </div>
        <center>Account :<?php echo $login_session; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="logout.php">logout</a></center>
        <div class="bank">
            <div class="h">
            <h3>Your Available Wallet Balance</h3>
            </div>
        <?php
            $result = mysqli_query($mysqli,"select *from wallet where phone = $login_session ");
				while($row=mysqli_fetch_array($result))
				{
                                    echo 'Wallet Balance: Rs.'.$row['bal'].'/-</br>';
                                   
                                }
	?>
        
                      
        
        </div>
    <div class="frm">
        <form action="payment.php" method="post" name="form" ng-app="myapp" ng-controller="valid" novalidate >
            
            <h3> Enter Amount:</h3>
            <input type="text" name="bal" required placeholder="100/-" maxlength="9" ng-model="bal" ng-pattern="/^[0-9]{1,9}$/" />
            <span style="color: red" ng-show="form.bal.$dirty && form.bal.$invalid" >
                        <span ng-show="form.bal.$error.required" >*phone number is required</span>
                        <span ng-show="form.bal.$error.pattern" >*Enter valid Ammount</span>
            </span>
            <p></p>
            
            <input type="submit" name="add" value="ADD" ng-disabled="form.$invalid" />
        </form>
    </div>
    <div>
        <h3>Our Services :</h3>
        <ul>
            <li><a href="show_wallet.php">Wallet</a></li>
            <li><a href="addbank.php">Add bank account</a></li>
            <li><a href="show_bank.php">Check Bank </a></li>
            <li><a href="add_debit.php">Add Debit Card</a></li>
            <li><a href="">Money Transfer</a></li>
            <li><a href="">Money Withdraw</a></li>
            <li><a href="">Bill Payment</a></li>
            <li><a href="">Recharge</a></li>
        </ul>
        
    </div>
    </body>
</html>

