<?php
   $dbhost = "localhost";
   $dbname = "suvankar";
   $dbuser = "suvankar";
   $dbpass = "root";

   $db = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
   session_start();
   
   $user_check = $_SESSION['login_user'];
   
   $ses_sql = mysqli_query($db,"select uname from login where uname = '$user_check' ");
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   
   $login_session = $row['uname'];
   /*$login_session1 = $row['lname'];
   $login_session2 = $row['phone'];*/
   
   if(!isset($_SESSION['login_user'])){
      header("location:login.php");
      die();
   }
?>